A Pen created at CodePen.io. You can find this one at https://codepen.io/ivan_antic/pen/yVQKpm.

 structure of sidebar-menu